import React, { useState } from "react";
import { Navbar, Nav, Container, Button } from "react-bootstrap";
import { BsMoon, BsSun } from "react-icons/bs";

const Header = ({ theme, toggleTheme }) => {
    const [expanded, setExpanded] = useState(false);

    return (
        <Navbar
            expanded={expanded}
            expand="lg"
            bg={theme === "dark" ? "dark" : "light"}
            variant={theme === "dark" ? "dark" : "light"}
            fixed="top"
            className="shadow-sm"
            data-aos="fade-down"
        >

            <Container>
                <Navbar.Brand href="#home" className="fw-bold fs-4">
                    Deep.dev
                </Navbar.Brand>

                <Navbar.Toggle
                    aria-controls="basic-navbar-nav"
                    onClick={() => setExpanded(!expanded)}
                />

                <Navbar.Collapse id="basic-navbar-nav">
                    <Nav className="ms-auto align-items-center">
                        <Nav.Link href="#about" onClick={() => setExpanded(false)}>
                            About
                        </Nav.Link>
                        <Nav.Link href="#skills" onClick={() => setExpanded(false)}>
                            Skills
                        </Nav.Link>
                        <Nav.Link href="#projects" onClick={() => setExpanded(false)}>
                            Projects
                        </Nav.Link>
                        <Nav.Link href="#contact" onClick={() => setExpanded(false)}>
                            Contact
                        </Nav.Link>

                        <Button
                            variant="outline-secondary"
                            className="ms-3 d-flex align-items-center"
                            onClick={toggleTheme}
                        >
                            {theme === "dark" ? <BsSun /> : <BsMoon />}
                        </Button>
                    </Nav>
                </Navbar.Collapse>
            </Container>
        </Navbar>
    );
};

export default Header;
// This code defines a responsive header component using React and React Bootstrap.
// It includes navigation links and a theme toggle button with icons for light and dark modes.
// The header collapses into a toggleable menu on smaller screens.
// The theme toggle button changes the icon based on the current theme, enhancing user experience.
// The component uses state to manage the expanded/collapsed state of the navbar.
// It is styled with Bootstrap classes and includes a fixed position at the top of the viewport.