import React from "react";
import { Container, Row, Col } from "react-bootstrap";

const About = ({ theme = "light" }) => {
    const isDark = theme === "dark";

    return (
        <section
            id="about"
            className={`py-5 ${isDark ? "bg-secondary text-light" : "bg-white text-dark"}`}
        >
            <Container>
                <h2 className="text-center mb-5 fw-bold" data-aos="fade-up">
                    About Me
                </h2>

                <Row className="align-items-center">
                    {/* Profile Image */}
                    <Col
                        md={5}
                        className="text-center mb-4 mb-md-0"
                        data-aos="fade-right"
                        data-aos-delay="100"
                    >
                        <img
                            src="https://avatars.githubusercontent.com/u/12345678?v=4"
                            alt="Deep Delvadiya"
                            className="img-fluid rounded-circle shadow"
                            style={{ width: "220px", height: "220px", objectFit: "cover" }}
                        />
                    </Col>

                    {/* Text Block with Modern Design */}
                    <Col md={7} data-aos="fade-left" data-aos-delay="200">
                        <div
                            className={`p-4 rounded-4 shadow-sm ${isDark
                                ? "bg-dark bg-opacity-75 border border-light"
                                : "bg-light bg-opacity-75 border border-secondary"
                                }`}
                            style={{
                                backdropFilter: "blur(10px)",
                            }}
                        >
                            <p className="mb-3">
                                👋 Hi, I’m <strong>Deep Delvadiya</strong>, a passionate Full Stack Developer
                                specializing in MERN (MongoDB, Express, React, Node.js). I love building clean,
                                performant web apps and exploring the latest tech trends.
                            </p>

                            <ul className="ps-3 mb-0">
                                <li data-aos="fade-up" data-aos-delay="300">💻 2+ Years Experience in Web Development</li>
                                <li data-aos="fade-up" data-aos-delay="400">🚀 Focused on scalable & optimized applications</li>
                                <li data-aos="fade-up" data-aos-delay="500">🌐 Open Source Contributor & Tech Blogger</li>
                                <li data-aos="fade-up" data-aos-delay="600">🎯 Clean Code | UI/UX Focused | Problem Solver</li>
                            </ul>
                        </div>
                    </Col>
                </Row>
            </Container>
        </section>
    );
};

export default About;
